﻿using System.Data.SqlClient;
using System;
using System.Data.Common;




namespace Api

{
    public class Person
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
