using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System;

namespace Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PersonController : ControllerBase
    {


        private static List<Person> Persons = [new Person { Id = 1, Name = "Name 1" }, new Person { Id = 2, Name = "Name 2" }];

        private readonly ILogger<PersonController> _logger;

        public PersonController(ILogger<PersonController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public List<Person> GetAll()
        {
            //return Persons;
            var persons = new List<Person>();
            SqlConnection conn = new SqlConnection(@"Server=.;Database=person;User Id=dev-user;Password=passw0rd;Trusted_Connection=True;");

            SqlCommand cmd = new SqlCommand("Select * from Persons", conn);
            conn.Open();

            SqlDataReader sqlDataReader = cmd.ExecuteReader();


            while (sqlDataReader.Read())
            {
                persons.Add(new Person()
                {
                    Id = (int)sqlDataReader["Id"],
                    Name = (string)sqlDataReader["Name"],
                });
            }
            conn.Close();

            return persons;
        }

        [HttpGet("{id:int}")]
        public List<Person> GetById(int id)
        {
            //return Persons;
            var persons = new List<Person>();
            SqlConnection conn = new SqlConnection(@"Server=.;Database=person;User Id=dev-user;Password=passw0rd;Trusted_Connection=True;");

            SqlCommand cmd = new SqlCommand("Select * from Persons", conn);
            conn.Open();

            SqlDataReader sqlDataReader = cmd.ExecuteReader();


            while (sqlDataReader.Read())
            {
                persons.Add(new Person()
                {
                    Id = (int)sqlDataReader["Id"],
                    Name = (string)sqlDataReader["Name"],
                });
            }
            conn.Close();

            return persons;
        }

        [HttpPost]
        public List<Person> Create(Person person)
        {
            Persons.Add(person);
            return Persons;
        }

        [HttpPut]
        public List<Person> Update(Person person)
        {
            Persons.Add(person);
            return Persons;
        }

        [HttpDelete]
        public List<Person> Delete(Person person)
        {
            Persons.Add(person);
            return Persons;
        }



    }
}
