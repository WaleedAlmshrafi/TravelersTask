﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TravelerProject.Migrations
{
    /// <inheritdoc />
    public partial class NewMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Birthday",
                table: "TravelersDb",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Email",
                table: "TravelersDb",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "FlightModelId",
                table: "TravelersDb",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Phone",
                table: "TravelersDb",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "FlightDb",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FlightId = table.Column<int>(type: "int", nullable: false),
                    DateFlight = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Starting = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Ending = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TimeStarting = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TimeEnding = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FlightDb", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TravelersDb_FlightModelId",
                table: "TravelersDb",
                column: "FlightModelId");

            migrationBuilder.AddForeignKey(
                name: "FK_TravelersDb_FlightDb_FlightModelId",
                table: "TravelersDb",
                column: "FlightModelId",
                principalTable: "FlightDb",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TravelersDb_FlightDb_FlightModelId",
                table: "TravelersDb");

            migrationBuilder.DropTable(
                name: "FlightDb");

            migrationBuilder.DropIndex(
                name: "IX_TravelersDb_FlightModelId",
                table: "TravelersDb");

            migrationBuilder.DropColumn(
                name: "Birthday",
                table: "TravelersDb");

            migrationBuilder.DropColumn(
                name: "Email",
                table: "TravelersDb");

            migrationBuilder.DropColumn(
                name: "FlightModelId",
                table: "TravelersDb");

            migrationBuilder.DropColumn(
                name: "Phone",
                table: "TravelersDb");
        }
    }
}
