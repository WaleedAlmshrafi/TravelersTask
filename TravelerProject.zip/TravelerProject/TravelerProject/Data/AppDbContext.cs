﻿using Microsoft.EntityFrameworkCore;
using TravelerProject.Models;

namespace TravelerProject.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options): base(options) 
        { 

        }
        public DbSet<TravelersModel> TravelersDb { get; set; }
        public DbSet<FlightModel> FlightDb { get; set; }
        
    }
}
