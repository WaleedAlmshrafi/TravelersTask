﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TravelerProject.Data;

namespace TravelerProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class APIController : ControllerBase
    {
        public APIController(AppDbContext db) 
        {
            _db = db;
        }
        private readonly AppDbContext _db;

        [HttpGet]
        public async Task<IActionResult> GetAPI()
        {
            var Traveler = await _db.TravelersDb.ToListAsync();
            return Ok(Traveler);
        }

        

    }
}
