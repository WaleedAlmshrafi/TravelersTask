﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TravelerProject.Data;

namespace TravelerProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class APIFlightController : ControllerBase
    {
        public APIFlightController(AppDbContext db)
        {
            _db = db;
        }
        private readonly AppDbContext _db;

        [HttpGet]
        public async Task<IActionResult> GetAPIFlight()
        {
            var Flight = await _db.FlightDb.ToListAsync();
            return Ok(Flight);
        }
    }
}
