﻿using Microsoft.AspNetCore.Mvc;
using TravelerProject.Data;
using TravelerProject.Models;

namespace TravelerProject.Controllers
{
    public class TravelersController : Controller
    {
        private readonly AppDbContext _db;
        public TravelersController(AppDbContext db)
        {
            _db = db;
        }

        
        public IActionResult Index()
        {
            var Travelers = _db.TravelersDb.ToList();
            var Flights = _db.FlightDb.ToList();
            ViewData["TravelersDb"] = Travelers;
            ViewData["FlightDb"] = Flights;
            return View();
        }

       
        public IActionResult Search(int? FlightID)
        {
            var Traveler = _db.TravelersDb.ToList().FindAll(x => x.FlightID == FlightID);
            
            ViewData["Traveler"] = Traveler;
            
            return View();
        }


        [HttpPost]
        public IActionResult Delete(int id)
        {
            var Flight = _db.TravelersDb.ToList().FirstOrDefault(x => x.Id == id);
            _db.TravelersDb.Remove(Flight);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }

        
        [HttpPost]
        public IActionResult DeleteFlight(int id)
        {
            
            var Flight = _db.FlightDb.ToList().FirstOrDefault(x => x.Id == id);
            int FlightID = Flight.FlightId;
            var Travelers = _db.TravelersDb.Where(x => x.FlightID == FlightID);
            _db.FlightDb.Remove(Flight);
            _db.TravelersDb.RemoveRange(Travelers);
            
            _db.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Create() 
        {
            var Flights = _db.FlightDb.ToList();
            ViewData["FlightDb"] = Flights;
            return View();
        }

        [HttpPost]
        public IActionResult Create([Bind("FlightID", "TravelerName", "TravelerID","Phone", "Birthday", "Email")]TravelersModel traveler)
        {
            _db.TravelersDb.Add(traveler);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult CreateFlight()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CreateFlight([Bind("FlightId", "DateFlight", "Starting", "Ending", "TimeStarting", "TimeEnding")] FlightModel flight)
        {
            _db.FlightDb.Add(flight);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }



        public IActionResult Edit(int? id)
        {
            var Traveler = _db.TravelersDb.ToList().Find(x => x.Id == id);
            ViewData["Traveler"]= Traveler;
            return View();
        }
        [HttpPost]
        public IActionResult Edit([Bind("Id", "FlightID", "TravelerName", "TravelerID", "Phone", "Birthday", "Email")] TravelersModel Traveler)
        {
            _db.TravelersDb.Update(Traveler);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult EditFlight(int? id)
        {
            var Flight = _db.FlightDb.ToList().Find(x => x.Id == id);
            ViewData["Flight"] = Flight;
            return View();
        }
        [HttpPost]
        public IActionResult EditFlight([Bind("Id", "FlightId", "DateFlight", "Starting", "Ending", "TimeStarting", "TimeEnding")] FlightModel Flight)
        {
            _db.FlightDb.Update(Flight);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
