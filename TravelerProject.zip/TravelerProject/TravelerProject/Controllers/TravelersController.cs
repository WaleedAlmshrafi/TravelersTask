﻿using Microsoft.AspNetCore.Mvc;
using TravelerProject.Data;
using TravelerProject.Models;

namespace TravelerProject.Controllers
{
    public class TravelersController : Controller
    {
        private readonly AppDbContext _db;
        public TravelersController(AppDbContext db)
        {
            _db = db;
        }

        
        public IActionResult Index()
        {
            var Travelers = _db.TravelersDb.ToList();
            ViewData["TravelersDb"] = Travelers;
            return View();
        }

        
        public IActionResult Search(int? FlightID)
        {
           
            var Flight = _db.TravelersDb.ToList().Find(x => x.FlightID == FlightID);
            //var count = _db.TravelersDb.Count();
            //ViewData["count"] = count;
            ViewData["Flight"] = Flight;
            return View();
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var Flight = _db.TravelersDb.ToList().FirstOrDefault(x => x.Id == id);
            _db.TravelersDb.Remove(Flight);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
        
        public IActionResult Create() 
        { 
            return View();
        }

        [HttpPost]
        public IActionResult Create([Bind("FlightID", "TravelerName", "TravelerID")]TravelersModel traveler)
        {
            _db.TravelersDb.Add(traveler);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }

        

        public IActionResult Edit(int? id)
        {
            var Traveler = _db.TravelersDb.ToList().Find(x => x.Id == id);
            ViewData["Traveler"]= Traveler;
            return View();
        }
        [HttpPost]
        public IActionResult Edit([Bind("Id", "FlightID", "TravelerName", "TravelerID")] TravelersModel Traveler)
        {
            _db.TravelersDb.Update(Traveler);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
