﻿namespace TravelerProject.Models
{
    public class TravelersModel
    {
        public int Id { get; set; }
        public int FlightID { get; set; }
        public string TravelerName { get; set; }
        public string TravelerID { get; set; }

        public int Phone { get; set; }
        
        public string Birthday { get; set; }

        public string Email { get; set; }


    }
}
