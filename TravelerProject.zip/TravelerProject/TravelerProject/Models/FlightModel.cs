﻿namespace TravelerProject.Models
{
    public class FlightModel
    {
        public int Id { get; set; }
        public int FlightId { get; set; }
        public string DateFlight { get; set; }

        public string Starting { get; set; }

        public string Ending { get; set; }

        public string TimeStarting { get; set; }

        public string TimeEnding { get; set; }

        public List<TravelersModel> Travelers { get; set; } = new List<TravelersModel>();
    }
}
